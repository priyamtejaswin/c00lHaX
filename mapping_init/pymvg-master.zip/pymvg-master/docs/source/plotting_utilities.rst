Plotting utilities
==================

Given the above example, we can plot the camera system.

.. plot:: pyplots/plot_camsystem_example.py
   :include-source:
