PyMVG file format
=================

The PyMVG file format specifies a camera system completely. The file
is valid JSON. Here is an example that specifies a system of 3
cameras:

.. literalinclude:: pymvg_camsystem_example.json
